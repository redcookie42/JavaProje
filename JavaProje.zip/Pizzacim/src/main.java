import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class main {

	static Connection myConn;
	static Statement myStat;
	
	
	static ResultSet baglanti_yap(){
		ResultSet myRs = null;
		try {
			myConn = (Connection) DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=pizzacim_takip;user=redcookie42;password=admin");
			myStat = (Statement) myConn.createStatement();
			myRs = myStat.executeQuery("select * from depo_urun");
				
		}catch(Exception es) {
			
		}
		return myRs;
	}
	
	static void ekle(String sorgu_ekle) {
		try {
			myStat.executeUpdate(sorgu_ekle);			
		}catch(Exception es) {
			
		}
	}
	
	static void sil(String sorgu_ekle) {
		try {
			myStat.executeUpdate(sorgu_ekle);
		}catch(Exception es) {
			
		}
	}
	
	
	
}
