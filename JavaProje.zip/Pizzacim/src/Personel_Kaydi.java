import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class Personel_Kaydi extends JFrame {

	private JPanel contentPane;
	private JTextField kullaniciAdi_textField;
	private JTextField tel_textField;
	private JTextField tc_textField;
	private JTextField eposta_textField;
	private JTextField dogrulama_textField;
	private JPasswordField sifre_textField;
	private JTextField isim_textField;
	private JTextField soyisim_textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Personel_Kaydi frame = new Personel_Kaydi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Personel_Kaydi() {
		setTitle("Personel Kayd\u0131");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 825, 492);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblKullancAd = new JLabel("Kullan\u0131c\u0131 Ad\u0131");
		lblKullancAd.setHorizontalAlignment(SwingConstants.LEFT);
		lblKullancAd.setForeground(Color.ORANGE);
		lblKullancAd.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblKullancAd.setBounds(37, 104, 148, 50);
		contentPane.add(lblKullancAd);
		
		JLabel lblifre = new JLabel("\u015Eifre");
		lblifre.setHorizontalAlignment(SwingConstants.LEFT);
		lblifre.setForeground(Color.ORANGE);
		lblifre.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblifre.setBounds(37, 165, 148, 50);
		contentPane.add(lblifre);
		
		JLabel lblTelefonNo = new JLabel("Telefon Numaras\u0131");
		lblTelefonNo.setHorizontalAlignment(SwingConstants.LEFT);
		lblTelefonNo.setForeground(Color.ORANGE);
		lblTelefonNo.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblTelefonNo.setBounds(37, 226, 148, 50);
		contentPane.add(lblTelefonNo);
		
		JLabel lblKimlikNo = new JLabel("TC Kimlik Numaras\u0131");
		lblKimlikNo.setHorizontalAlignment(SwingConstants.LEFT);
		lblKimlikNo.setForeground(Color.ORANGE);
		lblKimlikNo.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblKimlikNo.setBounds(424, 104, 148, 50);
		contentPane.add(lblKimlikNo);
		
		JLabel lblEposta = new JLabel("E-Posta");
		lblEposta.setHorizontalAlignment(SwingConstants.LEFT);
		lblEposta.setForeground(Color.ORANGE);
		lblEposta.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblEposta.setBounds(424, 165, 148, 50);
		contentPane.add(lblEposta);
		
		JLabel lblDorulamaKodu = new JLabel("Do\u011Frulama Kodu");
		lblDorulamaKodu.setHorizontalAlignment(SwingConstants.LEFT);
		lblDorulamaKodu.setForeground(Color.ORANGE);
		lblDorulamaKodu.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblDorulamaKodu.setBounds(424, 226, 148, 50);
		contentPane.add(lblDorulamaKodu);
		
		kullaniciAdi_textField = new JTextField();
		kullaniciAdi_textField.setHorizontalAlignment(SwingConstants.CENTER);
		kullaniciAdi_textField.setForeground(Color.WHITE);
		kullaniciAdi_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		kullaniciAdi_textField.setColumns(10);
		kullaniciAdi_textField.setBackground(Color.GRAY);
		kullaniciAdi_textField.setBounds(203, 116, 181, 26);
		contentPane.add(kullaniciAdi_textField);
		
		tel_textField = new JTextField();
		tel_textField.setHorizontalAlignment(SwingConstants.CENTER);
		tel_textField.setForeground(Color.WHITE);
		tel_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		tel_textField.setColumns(10);
		tel_textField.setBackground(Color.GRAY);
		tel_textField.setBounds(203, 238, 181, 26);
		contentPane.add(tel_textField);
		
		tc_textField = new JTextField();
		tc_textField.setHorizontalAlignment(SwingConstants.CENTER);
		tc_textField.setForeground(Color.WHITE);
		tc_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		tc_textField.setColumns(10);
		tc_textField.setBackground(Color.GRAY);
		tc_textField.setBounds(590, 116, 181, 26);
		contentPane.add(tc_textField);
		
		eposta_textField = new JTextField();
		eposta_textField.setHorizontalAlignment(SwingConstants.CENTER);
		eposta_textField.setForeground(Color.WHITE);
		eposta_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		eposta_textField.setColumns(10);
		eposta_textField.setBackground(Color.GRAY);
		eposta_textField.setBounds(590, 177, 181, 26);
		contentPane.add(eposta_textField);
		
		dogrulama_textField = new JTextField();
		dogrulama_textField.setHorizontalAlignment(SwingConstants.CENTER);
		dogrulama_textField.setForeground(Color.WHITE);
		dogrulama_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		dogrulama_textField.setColumns(10);
		dogrulama_textField.setBackground(Color.GRAY);
		dogrulama_textField.setBounds(590, 238, 181, 26);
		contentPane.add(dogrulama_textField);
		
		sifre_textField = new JPasswordField();
		sifre_textField.setHorizontalAlignment(SwingConstants.CENTER);
		sifre_textField.setForeground(Color.WHITE);
		sifre_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		sifre_textField.setBackground(Color.GRAY);
		sifre_textField.setBounds(204, 177, 180, 26);
		contentPane.add(sifre_textField);
		
		JButton kayit_btn = new JButton("KAYDI OLU\u015ETUR");
		kayit_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String kullaniciAdii = kullaniciAdi_textField.getText();
				String sifree = sifre_textField.getText();
				String tell = tel_textField.getText();
				String tcc = tc_textField.getText();
				String postaa = eposta_textField.getText();
				String dogrulamaa = dogrulama_textField.getText();
				String isimm = isim_textField.getText();
				String soyisimm = soyisim_textField.getText();
				
				if(kullaniciAdii.trim().equals("") || sifree.trim().equals("") || tell.trim().equals("") || 
			                 tcc.trim().equals("") || postaa.trim().equals("") || dogrulamaa.trim().equals("") ||
			                 isimm.trim().equals("") || soyisimm.trim().equals("")) {
					
					JOptionPane.showMessageDialog(null,"�lgili Alanlar� Tam Doldurunuz.");
					
				}else {
					try{
					      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
					      String url = "jdbc:sqlserver://localhost:1433;databaseName=pizzacim_takip;user=redcookie42;password=admin";
					      Connection con = DriverManager.getConnection(url);
					      String sql = "Select * from dogrulama_kodlari where dogrulama_kodu=?";
					      PreparedStatement pst = con.prepareStatement(sql);
					      pst.setString(1,dogrulamaa.toString());//kontrol1
					      ResultSet rs = pst.executeQuery();//kodu execute ediyoruz.
					      if(rs.next()){//e�er ilgili sorgu sonras� bir veri geliyor ise
					          			
					    	  try {
					    		  String personel_ekle = "insert into personel_bilgi values(" + "'" + isimm + "'" + "," + "'" + soyisimm + "'" + 
					    	        "," + tcc + "," + tell + "," + "'" + "NULL" + "'" + "," + "'" + "NULL" + "'" + "," + "'" + 
					    		    kullaniciAdii + "'" + "," + "'" + sifree + "'" + "," + dogrulamaa + ")";
					    		    main.ekle(personel_ekle);
					                JOptionPane.showMessageDialog(null,"Kay�t Ba�ar�l�!");
					                
					    	  }catch(Exception es) {
					    		  JOptionPane.showMessageDialog(null, es);
					    	  }
					          		
					      }else{
					          JOptionPane.showMessageDialog(null,"Girilen Do�rulama Kodu Yanl��. Tekrar Deneyiniz!");
					          
					      }
					        con.close();
					    }
					  catch(Exception es){
					        JOptionPane.showMessageDialog(null, es);
					    }
				}
			}
		});
		kayit_btn.setBounds(37, 363, 734, 62);
		contentPane.add(kayit_btn);
		
		JLabel lblYetkiliKaydOluturma = new JLabel("Personel Kayd\u0131 Olu\u015Fturma Paneli");
		lblYetkiliKaydOluturma.setHorizontalAlignment(SwingConstants.CENTER);
		lblYetkiliKaydOluturma.setForeground(Color.GREEN);
		lblYetkiliKaydOluturma.setFont(new Font("Segoe UI", Font.BOLD, 29));
		lblYetkiliKaydOluturma.setBounds(143, 27, 529, 50);
		contentPane.add(lblYetkiliKaydOluturma);
		
		JLabel lblIsim = new JLabel("\u0130sim");
		lblIsim.setHorizontalAlignment(SwingConstants.LEFT);
		lblIsim.setForeground(Color.ORANGE);
		lblIsim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblIsim.setBounds(37, 287, 148, 50);
		contentPane.add(lblIsim);
		
		isim_textField = new JTextField();
		isim_textField.setHorizontalAlignment(SwingConstants.CENTER);
		isim_textField.setForeground(Color.WHITE);
		isim_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		isim_textField.setColumns(10);
		isim_textField.setBackground(Color.GRAY);
		isim_textField.setBounds(203, 299, 181, 26);
		contentPane.add(isim_textField);
		
		JLabel lblSoyisim = new JLabel("Soyisim");
		lblSoyisim.setHorizontalAlignment(SwingConstants.LEFT);
		lblSoyisim.setForeground(Color.ORANGE);
		lblSoyisim.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblSoyisim.setBounds(424, 287, 148, 50);
		contentPane.add(lblSoyisim);
		
		soyisim_textField = new JTextField();
		soyisim_textField.setHorizontalAlignment(SwingConstants.CENTER);
		soyisim_textField.setForeground(Color.WHITE);
		soyisim_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		soyisim_textField.setColumns(10);
		soyisim_textField.setBackground(Color.GRAY);
		soyisim_textField.setBounds(590, 299, 181, 26);
		contentPane.add(soyisim_textField);
	}
}
