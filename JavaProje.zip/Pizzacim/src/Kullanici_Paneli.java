import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class Kullanici_Paneli extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	DefaultTableModel modelim = new DefaultTableModel();
	Object[] kolonlar = {"�R�N ID","�R�N �S�M","�R�N KATEGOR�","�R�N ADET�","�R�N F�YATI","�R�N MARKA"};
	Object[] satirlar = new Object[6];
	private JTextField ismi_textField;
	private JTextField kategori_textField;
	private JTextField adet_textField;
	private JTextField fiyat_textField;
	private JTextField marka_textField;
	private JTextField silinecek_textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Kullanici_Paneli frame = new Kullanici_Paneli();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Kullanici_Paneli() {
		setTitle("Yetkili Paneli");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1050, 554);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 85, 665, 419);
		contentPane.add(scrollPane);
		
		table = new JTable();
		modelim.setColumnIdentifiers(kolonlar);
		
		table.setBounds(59, 186, 356, 136);
		//contentPane.add(table);
		scrollPane.setViewportView(table);
		
		JButton btnVerileriListele = new JButton("VER\u0130LER\u0130 L\u0130STELE");
		btnVerileriListele.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modelim.setRowCount(0);
				try {
					ResultSet myRs = main.baglanti_yap();
					
				    while(myRs.next()) {
				        satirlar[0] = myRs.getString("urun_id");
				        satirlar[1] = myRs.getString("urun_isim");
				        satirlar[2] = myRs.getString("urun_kategori");
				        satirlar[3] = myRs.getString("urun_adeti");
				        satirlar[4] = myRs.getString("urun_fiyati");
				        satirlar[5] = myRs.getString("urun_marka");
				        modelim.addRow(satirlar);				        
				    }					
					table.setModel(modelim);
					JOptionPane.showMessageDialog(null, "Kay�tlar Ba�ar�l� Bir �ekilde Listelendi.");
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		btnVerileriListele.setBounds(685, 341, 157, 50);
		contentPane.add(btnVerileriListele);
		
		JLabel lblKullancAd = new JLabel("\u00DCr\u00FCn \u0130smi");
		lblKullancAd.setHorizontalAlignment(SwingConstants.CENTER);
		lblKullancAd.setForeground(Color.ORANGE);
		lblKullancAd.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblKullancAd.setBounds(679, 85, 148, 50);
		contentPane.add(lblKullancAd);
		
		ismi_textField = new JTextField();
		ismi_textField.setHorizontalAlignment(SwingConstants.CENTER);
		ismi_textField.setForeground(Color.WHITE);
		ismi_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		ismi_textField.setColumns(10);
		ismi_textField.setBackground(Color.GRAY);
		ismi_textField.setBounds(818, 95, 181, 26);
		contentPane.add(ismi_textField);
		
		JButton btnSil = new JButton("S\u0130L");
		btnSil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String ismii,sqlsorgu;
					ismii = silinecek_textField.getText();
					sqlsorgu = "DELETE FROM depo_urun where urun_isim=" + "'" +  ismii + "'";
					main.sil(sqlsorgu);
					JOptionPane.showMessageDialog(null, "Veri Ba�ar�yla Silindi.");
				}catch(Exception es) {
					JOptionPane.showMessageDialog(null, "Veri Silinirken Bir Hata Meydana Geldi!");
				}
					
					
			}
		});
		btnSil.setBounds(685, 459, 339, 45);
		contentPane.add(btnSil);
		
		JLabel lblrnKategori = new JLabel("\u00DCr\u00FCn Kategori");
		lblrnKategori.setHorizontalAlignment(SwingConstants.CENTER);
		lblrnKategori.setForeground(Color.ORANGE);
		lblrnKategori.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblrnKategori.setBounds(679, 132, 148, 50);
		contentPane.add(lblrnKategori);
		
		kategori_textField = new JTextField();
		kategori_textField.setHorizontalAlignment(SwingConstants.CENTER);
		kategori_textField.setForeground(Color.WHITE);
		kategori_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		kategori_textField.setColumns(10);
		kategori_textField.setBackground(Color.GRAY);
		kategori_textField.setBounds(818, 142, 181, 26);
		contentPane.add(kategori_textField);
		
		JLabel lblrnAdeti = new JLabel("\u00DCr\u00FCn Adeti");
		lblrnAdeti.setHorizontalAlignment(SwingConstants.CENTER);
		lblrnAdeti.setForeground(Color.ORANGE);
		lblrnAdeti.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblrnAdeti.setBounds(679, 179, 148, 50);
		contentPane.add(lblrnAdeti);
		
		adet_textField = new JTextField();
		adet_textField.setHorizontalAlignment(SwingConstants.CENTER);
		adet_textField.setForeground(Color.WHITE);
		adet_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		adet_textField.setColumns(10);
		adet_textField.setBackground(Color.GRAY);
		adet_textField.setBounds(818, 189, 181, 26);
		contentPane.add(adet_textField);
		
		JLabel lblrnFiyat = new JLabel("\u00DCr\u00FCn Fiyat\u0131");
		lblrnFiyat.setHorizontalAlignment(SwingConstants.CENTER);
		lblrnFiyat.setForeground(Color.ORANGE);
		lblrnFiyat.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblrnFiyat.setBounds(679, 226, 148, 50);
		contentPane.add(lblrnFiyat);
		
		fiyat_textField = new JTextField();
		fiyat_textField.setHorizontalAlignment(SwingConstants.CENTER);
		fiyat_textField.setForeground(Color.WHITE);
		fiyat_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		fiyat_textField.setColumns(10);
		fiyat_textField.setBackground(Color.GRAY);
		fiyat_textField.setBounds(818, 236, 181, 26);
		contentPane.add(fiyat_textField);
		
		JLabel lblrnMarka = new JLabel("\u00DCr\u00FCn Marka");
		lblrnMarka.setHorizontalAlignment(SwingConstants.CENTER);
		lblrnMarka.setForeground(Color.ORANGE);
		lblrnMarka.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblrnMarka.setBounds(679, 273, 148, 50);
		contentPane.add(lblrnMarka);
		
		marka_textField = new JTextField();
		marka_textField.setHorizontalAlignment(SwingConstants.CENTER);
		marka_textField.setForeground(Color.WHITE);
		marka_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		marka_textField.setColumns(10);
		marka_textField.setBackground(Color.GRAY);
		marka_textField.setBounds(818, 283, 181, 26);
		contentPane.add(marka_textField);
		
		JButton btnEkle = new JButton("EKLE");
		btnEkle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String isim,kategori,adet,fiyat,marka,sql_sorgu2;
					isim = ismi_textField.getText();
					kategori = kategori_textField.getText();
					adet = adet_textField.getText();
					fiyat = fiyat_textField.getText();
					marka = marka_textField.getText();
					
					if(isim.trim().equals("") || kategori.trim().equals("") || adet.trim().equals("") ||
					   fiyat.trim().equals("")|| marka.trim().equals("")) {
						   JOptionPane.showMessageDialog(null, "�lgili Yerleri Tam Doldurunuz!");
					}else {
						sql_sorgu2 = "insert into depo_urun values(" + "'" + isim + "'" + "," + "'" + kategori + "'" + "," + adet + "," + fiyat + "," + "'" + marka + "')";
						main.ekle(sql_sorgu2);
						JOptionPane.showMessageDialog(null, "Kay�t Ba�ar�l� Bir �ekilde Olu�turuldu.");
					}
					
				}catch(Exception es) {
					JOptionPane.showMessageDialog(null, "Kay�t Eklenirken Bir Hata Meydana Geldi!11111111");
				}
				
				
				
			}
		});
		btnEkle.setBounds(867, 341, 157, 50);
		contentPane.add(btnEkle);
		
		silinecek_textField = new JTextField();
		silinecek_textField.setHorizontalAlignment(SwingConstants.CENTER);
		silinecek_textField.setForeground(Color.WHITE);
		silinecek_textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		silinecek_textField.setColumns(10);
		silinecek_textField.setBackground(Color.GRAY);
		silinecek_textField.setBounds(861, 414, 157, 26);
		contentPane.add(silinecek_textField);
		
		JLabel lblrnIsmi = new JLabel("Silinecek \u00DCr\u00FCn \u0130smi");
		lblrnIsmi.setHorizontalAlignment(SwingConstants.CENTER);
		lblrnIsmi.setForeground(Color.ORANGE);
		lblrnIsmi.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblrnIsmi.setBounds(695, 402, 148, 50);
		contentPane.add(lblrnIsmi);
		
		JLabel lblPizzacmDeporn = new JLabel("Pizzac\u0131m Depo \u00DCr\u00FCn Tablosu");
		lblPizzacmDeporn.setHorizontalAlignment(SwingConstants.CENTER);
		lblPizzacmDeporn.setForeground(Color.GREEN);
		lblPizzacmDeporn.setFont(new Font("Segoe UI", Font.BOLD | Font.ITALIC, 39));
		lblPizzacmDeporn.setBounds(195, 11, 621, 53);
		contentPane.add(lblPizzacmDeporn);
		
	}
}
