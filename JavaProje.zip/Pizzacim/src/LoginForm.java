import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class LoginForm extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm frame = new LoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void close() {
		WindowEvent winClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
	    Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
	}
	
	public LoginForm() {
		setTitle("Pizzac\u0131m Depo Takip Program\u0131");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 389, 308);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Pizzac\u0131m Depo Takip");
		lblNewLabel.setForeground(Color.GREEN);
		lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 29));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(37, 28, 293, 50);
		contentPane.add(lblNewLabel);
		
		JLabel lblKullancAd = new JLabel("Kullan\u0131c\u0131 Ad\u0131");
		lblKullancAd.setHorizontalAlignment(SwingConstants.CENTER);
		lblKullancAd.setForeground(Color.ORANGE);
		lblKullancAd.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblKullancAd.setBounds(10, 89, 148, 50);
		contentPane.add(lblKullancAd);
		
		JLabel lblifre = new JLabel("\u015Eifre ");
		lblifre.setHorizontalAlignment(SwingConstants.CENTER);
		lblifre.setForeground(Color.ORANGE);
		lblifre.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblifre.setBounds(10, 136, 148, 50);
		contentPane.add(lblifre);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setForeground(Color.WHITE);
		textField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		textField.setBackground(Color.GRAY);
		textField.setBounds(149, 99, 181, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setForeground(Color.WHITE);
		passwordField.setFont(new Font("Segoe UI", Font.BOLD, 15));
		passwordField.setBackground(Color.GRAY);
		passwordField.setBounds(150, 149, 180, 26);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("G\u0130R\u0130\u015E YAP");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
				      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				      String url = "jdbc:sqlserver://localhost:1433;databaseName=pizzacim_takip;user=redcookie42;password=admin";
				      Connection con = DriverManager.getConnection(url);
				      String sql = "Select * from personel_bilgi where personel_kullaniciAdi=? and personel_sifre=?"; //veritaban�ndaki kullanc�lar tablomuzdan kullan�c�ad� �ifre kontrol� yap�yoruz
				      PreparedStatement pst = con.prepareStatement(sql);
				      pst.setString(1,textField.getText());//kontrol1
				      pst.setString(2,passwordField.getText());//kontrol2
				      ResultSet rs = pst.executeQuery();//kodu execute ediyoruz.
				      if(rs.next()){//e�er ilgili sorgu sonras� bir veri geliyor ise
				          JOptionPane.showMessageDialog(null,"Giri� Ba�ar�l�. Yetkili Aray�z�ne Aktar�l�yorsunuz...");
				          Kullanici_Paneli frm2 = new Kullanici_Paneli();	
				         
				          frm2.setVisible(true);
				          close();
				         
				          
				      }else{
				          JOptionPane.showMessageDialog(null,"Giri� ��lemi Ba�ar�s�z. Kullan�c� Ad� Veya �ifre Hatal�!");
				          textField.setText("");
				          passwordField.setText("");
				      }
				        con.close();
				    }
				  catch(Exception es){
				        JOptionPane.showMessageDialog(null, es);
				    }
				
			}
		});
		btnNewButton.setBounds(20, 200, 157, 50);
		contentPane.add(btnNewButton);
		
		JButton btnYetkiliKaydYap = new JButton("YETK\u0130L\u0130 KAYDI YAP");
		btnYetkiliKaydYap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Personel_Kaydi frm3 = new Personel_Kaydi();
				frm3.setVisible(true);
			}
		});
		btnYetkiliKaydYap.setBounds(195, 200, 157, 50);
		contentPane.add(btnYetkiliKaydYap);
	}
}
